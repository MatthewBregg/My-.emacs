Auto Complete Mode
==================

Documentation
-------------

* http://cx4a.org/software/auto-complete/
* doc/index.txt

License
-------

Auto Complete Mode is distributed under the term of GPLv3. And its documentations under doc directory is distributed under the term of GFDL.
